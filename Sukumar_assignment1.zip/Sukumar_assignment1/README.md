# Terraform AWS Infrastructure - Module Based Deployment

This project uses Terraform to deploy a modular AWS infrastructure including:
- VPC (Virtual Private Cloud)
- EC2 Instances
- RDS Database
- Security Groups

## ?? Project Structure

```
module-lab/
+-- main.tf                # Root module calling sub-modules
+-- variables.tf           # Input variables for root module
+-- outputs.tf             # Output values from the deployment
+-- modules/
�   +-- vpc/               # VPC creation
�   +-- ec2/               # EC2 instance provisioning
�   +-- rds/               # RDS database provisioning
�   +-- security-groups/   # Security group rules
```

---

## ? Prerequisites

- [Terraform](https://developer.hashicorp.com/terraform/downloads) v1.0+
- AWS CLI configured with access key and secret (`aws configure`)
- An active AWS account

---

## ?? Usage

### 1. Clone the Repository

```bash
git clone <repo-url>
cd module-lab
```

### 2. Initialize Terraform

```bash
terraform init
```

### 3. Review the Execution Plan

```bash
terraform plan -out=tfplan.out
```

### 4. Apply the Configuration

```bash
terraform apply "tfplan.out"
```

### 5. Destroy the Infrastructure (when needed)

```bash
terraform destroy
```

---

## ?? Module Descriptions

### `modules/vpc`
Creates a VPC with subnets, route tables, and internet gateway.

### `modules/security-groups`
Defines security group rules for EC2 and RDS access.

### `modules/ec2`
Provisions EC2 instances using defined AMI, instance type, and key pair.

### `modules/rds`
Creates an RDS instance within a private subnet.

---

## ?? Outputs

After successful apply, run:

```bash
terraform output
```

To see key outputs like:
- VPC ID
- EC2 instance public IP
- RDS endpoint

---

## ?? Notes

- Ensure all variable values (e.g., AMI ID, key names) are set appropriately in `terraform.tfvars` or passed via CLI.
- Sensitive values like DB passwords should be stored securely (e.g., use environment variables or secrets manager).

---

## ?? Contact

For help or questions, please contact [your-email@example.com].
